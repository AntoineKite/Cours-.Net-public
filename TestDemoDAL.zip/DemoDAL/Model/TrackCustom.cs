﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDAL.Model
{
    public class TrackCustom
    {
        public string TrackName { get; set; }
        public string AlbumName { get; set; }
        public string Composer { get; set; }
        public string ArtisteName { get; set; }
        public string MediaTypeName { get; set; }
    }
}
