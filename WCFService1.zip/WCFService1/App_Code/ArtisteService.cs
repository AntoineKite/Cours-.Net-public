﻿using DemoDAL;
using DemoDAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "Service" dans le code, le fichier svc et le fichier de configuration.
public class ArtisteService : IArtisteService
{
    UnitOfWork _UnitOfWork = new UnitOfWork();

    public ArtisteService()
    {

    }


    public List<ArtisteNbAlbums> GetNbAlbumsArtiste()
    {
        return _UnitOfWork.ArtisteRepo.GetNbAlbumsArtiste();
        //return new List<int>() { 1 };
    }




}
