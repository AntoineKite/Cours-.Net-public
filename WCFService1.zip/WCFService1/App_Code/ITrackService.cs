﻿
using DemoDAL;
using DemoDAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom d'interface "ITrackService" à la fois dans le code et le fichier de configuration.
[ServiceContract]
public interface ITrackService
{
    [OperationContract]
    List<Track> GetTrackByComposer(string composer);

    [OperationContract]
    List<TrackCustom> GetTrackCustomByComposer(string composer);

    [OperationContract]
    void UpdateTrack(TrackCustom trackCustom);

    [OperationContract]
    TrackCustom GetTrackCustomFictif();
}
