﻿using DemoDAL;
using DemoDAL.Model;
using DemoDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "TrackService" à la fois dans le code, le fichier svc et le fichier de configuration.
public class TrackService : ITrackService
{
    UnitOfWork _UnitOfWork = new UnitOfWork();

    public List<Track> GetTrackByComposer(string composer)
    {
        var result = _UnitOfWork.TrackRepo.GetTrackByComposer(composer);
        return result;
    }

    public List<TrackCustom> GetTrackCustomByComposer(string composer)
    {
        return _UnitOfWork.TrackRepo.GetTrackCustomByComposer(composer);
    }

    public void UpdateTrack(TrackCustom trackCustom)
    {
        Track track = _UnitOfWork.TrackRepo.GetTrackById(trackCustom.TrackId);
        track.Name = trackCustom.TrackName;
        _UnitOfWork.Save();
        
    }
    
    public TrackCustom GetTrackCustomFictif()
    {
        return new TrackCustom() { AlbumName = "X", Composer = "AC/DC", TrackName = "Thunderstrick" };
    }    
}
