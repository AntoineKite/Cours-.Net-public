﻿using DemoDAL;
using DemoDAL.Model;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace WebAPI.Controllers
{
    //[EnableCors(origins: "*", headers: "*", methods: "*")]
    public class TrackController : ApiController
    {
        UnitOfWork _UnitOfWork = new UnitOfWork();


        // GET: Track?composer=AC/DC        
        public IEnumerable<TrackCustom> GetTrackByComposer(string composer)
        {
            return _UnitOfWork.TrackRepo.GetTrackCustomByComposer(composer).AsEnumerable();
        }

        [HttpGet]
        [Route("api/trackCustomById/{id}")]
        public TrackCustom GetTrackCustomById(int id)
        {
            return _UnitOfWork.TrackRepo.GetTrackCustomById(id);
        }

        [HttpPost]
        public HttpResponseMessage Post ([FromBody] Track track)
        {
            try
            {
                _UnitOfWork.TrackRepo.Add(track);
                _UnitOfWork.Save();
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch(Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
            
        }

        [HttpGet]
        public Track GetById(int id)
        {
            return _UnitOfWork.TrackRepo.GetTrackById(id);
        }

        
    }
}
